Set of tools for processing satellite altimetry data
====================================================

Description coming soon...
